package com.sau.userAuthentication.models;

public enum ERole {
  OWNER,
  MANAGER,
  RECEPTIONIST
}
